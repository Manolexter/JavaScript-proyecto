var calculadora = {
  EventosClick: function(){
		document.getElementById("0").addEventListener("click",function(){calculadora.viewnum("0")});
		document.getElementById("1").addEventListener("click",function(){calculadora.viewnum("1")});
		document.getElementById("2").addEventListener("click",function(){calculadora.viewnum("2")});
		document.getElementById("3").addEventListener("click",function(){calculadora.viewnum("3")});
		document.getElementById("4").addEventListener("click",function(){calculadora.viewnum("4")});
		document.getElementById("5").addEventListener("click",function(){calculadora.viewnum("5")});
		document.getElementById("6").addEventListener("click",function(){calculadora.viewnum("6")});
		document.getElementById("7").addEventListener("click",function(){calculadora.viewnum("7")});
		document.getElementById("8").addEventListener("click",function(){calculadora.viewnum("8")});
		document.getElementById("9").addEventListener("click",function(){calculadora.viewnum("9")});
		document.getElementById("on").addEventListener("click",function(){calculadora.on("")});
		document.getElementById("sign").addEventListener("click",function(){calculadora.sign()});
		document.getElementById("dividido").addEventListener("click",function(){calculadora.dividido()});
		document.getElementById("menos").addEventListener("click",function(){calculadora.menos()});
		document.getElementById("punto").addEventListener("click",function(){calculadora.punto()});
		document.getElementById("igual").addEventListener("click",function(){calculadora.igual()});
		document.getElementById("mas").addEventListener("click",function(){calculadora.mas()});
		document.getElementById("por").addEventListener("click",function(){calculadora.por()});
	},

  pantalla: document.getElementById("display").innerHTML,
	decimal: 0,
	signo: 0,
	comprobar: 8,
	detener: 0,
	num1: 0,
	opcion: 0,
	auxnum: 0,
	incrementar: 0,
	resultado: 0,
	inicio: (
		function(){
			this.EventosClick();
		}
	),
	botones: function(tecla){
		document.getElementById(tecla).style.transform="scale(0.9)";
		setTimeout(function() {document.getElementById(tecla).style.transform="scale(1)";}, 200);
	},

  mas: function(){
        this.botones("mas");
      this.num1 += Number(this.pantalla),
      this.pantalla = "",
      this.opcion = 1,
      this.incrementar = 0,
      this.signo = 0,
      this.auxnum = 0,
      this.incrementar = 0,
      this.decimal = 0,
      this.viewdisplay();
  },
  menos: function(){
      this.botones("menos");
    this.num1 = Number(this.pantalla);
    this.pantalla = "",
    this.opcion = 2,
    this.incrementar = 0,
    this.signo = 0,
    this.auxnum = 0,
    this.incrementar = 0,
    this.decimal = 0,
    this.viewdisplay();
},
  por: function(){
      this.botones("por");
    this.num1 = Number(this.pantalla),
    this.pantalla = "",
    this.opcion = 3,
    this.incrementar = 0,
    this.signo = 0,
    this.auxnum = 0,
    this.incrementar = 0,
    this.decimal = 0,
    this.viewdisplay();
},
  dividido: function(){
      this.botones("dividido");
    this.num1 = Number(this.pantalla),
    this.pantalla = "",
    this.opcion = 4,
    this.incrementar = 0,
    this.signo = 0,
    this.auxnum = 0,
    this.incrementar = 0,
    this.decimal = 0,
    this.viewdisplay();
},

viewnum: function(valor){
  this.botones(valor);
  if(this.signo == 1 && this.detener == 0){
    this.comprobar += 1,
    this.detener = 1;
  }
  if(this.decimal == 1  && this.detener == 0){
    this.comprobar += 1,
    this.detener = 1;
  }
  if(this.pantalla.length < this.comprobar){
    if(this.pantalla != "0"){
      this.pantalla += valor;
    }else if(valor != 0){
      this.pantalla = "",
      this.pantalla += valor;
    }
    this.viewdisplay();
  }
},
on: function(){
  this.botones("on");
  this.pantalla = "0",
  this.decimal = 0,
  this.signo = 0,
  this.detener = 0,
  this.comprobar = 8
  this.num1 = 0,
  this.incrementar = 0,
  this.auxnum = 0,
  this.opcion = 0,
  this.resultado = 0,
  this.viewdisplay();
},
sign: function(){
  this.botones("sign");
  if(this.pantalla != 0){
    if(this.signo == 0){
      this.pantalla = "-" + this.pantalla,
      this.signo = 1;
    }else{
      this.pantalla = this.pantalla.slice(1);
      this.signo = 0;
    }
  }
  this.viewdisplay();
},
punto: function(){
  this.botones("punto");
  if(this.decimal == 0){
    this.pantalla += ".";
  }
  this.decimal = 1,
  this.viewdisplay();
},
viewdisplay: function(){
  if(this.pantalla.toString().length > this.comprobar){
    this.pantalla = this.pantalla.toString().substring(0,8);
  }
  document.getElementById("display").innerHTML = this.pantalla;
},

igual: function(){
  this.botones("igual");
  switch(this.opcion){
    case 1:
        if(this.incrementar == 0){
          this.auxnum = Number(this.pantalla),
          this.pantalla = this.num1 + Number(this.pantalla),
          this.incrementar = 1,
          this.num1 = 0;
        }else{
          this.pantalla = Number(this.pantalla)+this.auxnum;
        }
      break;
    case 2:
        if(this.incrementar == 0){
          this.auxnum = Number(this.pantalla),
          this.pantalla = this.num1 - Number(this.pantalla),
          this.incrementar = 1,
          this.num1 = 0;
        }else{
          this.pantalla = Number(this.pantalla)-this.auxnum;
        }
      break;
    case 3:
        if(this.incrementar == 0){
          this.auxnum = Number(this.pantalla),
          this.pantalla = this.num1 * Number(this.pantalla),
          this.incrementar = 1,
          this.num1 = 0;
        }else{
          this.pantalla = Number(this.pantalla)*this.auxnum;
        }
      break;
    case 4:
        if(this.incrementar == 0){
          this.auxnum = Number(this.pantalla),
          this.pantalla = this.num1 / Number(this.pantalla),
          this.incrementar = 1,
          this.num1 = 0;
        }else{
          this.pantalla = Number(this.pantalla)/this.auxnum;
        }
      break;
    default:
      break;
  }
  this.viewdisplay();
}

}
calculadora.inicio();
